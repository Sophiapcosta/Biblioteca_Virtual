<?php
$livros = json_decode(file_get_contents('dados.json'), true);
$id = $_GET['id'];
if (isset($livros[$id])) {
    unset($livros[$id]);
    $livros = array_values($livros);
    file_put_contents('dados.json', json_encode($livros, JSON_PRETTY_PRINT));
}
header("Location: index.php");
exit;
?>