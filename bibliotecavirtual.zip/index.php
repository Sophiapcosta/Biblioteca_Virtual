<?php
$livros = json_decode(file_get_contents('dados.json'), true);
if (!$livros) $livros = [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Biblioteca Virtual</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/script.js" defer></script>
</head>
<body class="bg-light">
<div class="container mt-5">
  <h1 class="mb-4 text-center">📚 Biblioteca Virtual</h1>
  <div class="d-flex justify-content-between mb-3">
    <input type="text" id="search" class="form-control w-50" placeholder="Buscar livro...">
    <a href="adicionar.php" class="btn btn-primary">+ Adicionar Livro</a>
  </div>
  <table class="table table-striped" id="tabelaLivros">
    <thead class="table-dark">
      <tr><th>#</th><th>Título</th><th>Autor</th><th>Categoria</th><th>Ações</th></tr>
    </thead>
    <tbody>
      <?php if (count($livros) > 0): ?>
        <?php foreach ($livros as $i => $livro): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= htmlspecialchars($livro['titulo']) ?></td>
            <td><?= htmlspecialchars($livro['autor']) ?></td>
            <td><?= htmlspecialchars($livro['categoria']) ?></td>
            <td>
              <a href="editar.php?id=<?= $i ?>" class="btn btn-sm btn-warning">Editar</a>
              <a href="excluir.php?id=<?= $i ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="5" class="text-center">Nenhum livro cadastrado.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<footer>Biblioteca Virtual © 2025 — Desenvolvido com PHP & JSON</footer>
</body>
</html>
