<?php
$livros = json_decode(file_get_contents('dados.json'), true);
$id = $_GET['id'];
if (!isset($livros[$id])) die("Livro não encontrado!");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $livros[$id] = [
        'titulo' => $_POST['titulo'],
        'autor' => $_POST['autor'],
        'categoria' => $_POST['categoria']
    ];
    file_put_contents('dados.json', json_encode($livros, JSON_PRETTY_PRINT));
    header("Location: index.php");
    exit;
}
$livro = $livros[$id];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Editar Livro</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2>Editar Livro</h2>
  <form method="post" class="mt-3">
    <div class="mb-3">
      <label>Título:</label>
      <input type="text" name="titulo" value="<?= htmlspecialchars($livro['titulo']) ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Autor:</label>
      <input type="text" name="autor" value="<?= htmlspecialchars($livro['autor']) ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Categoria:</label>
      <input type="text" name="categoria" value="<?= htmlspecialchars($livro['categoria']) ?>" class="form-control" required>
    </div>
    <button class="btn btn-success">Salvar</button>
    <a href="index.php" class="btn btn-secondary">Voltar</a>
  </form>
</div>
<footer>Biblioteca Virtual © 2025 — Desenvolvido com PHP & JSON</footer>
</body>
</html>
