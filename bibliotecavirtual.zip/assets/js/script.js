document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("search");
  const rows = document.querySelectorAll("#tabelaLivros tbody tr");
  searchInput.addEventListener("keyup", () => {
    const termo = searchInput.value.toLowerCase();
    rows.forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(termo) ? "" : "none";
    });
  });
});